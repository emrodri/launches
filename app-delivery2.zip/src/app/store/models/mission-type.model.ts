export interface MissionType {
  id: number;
  name: string;
  changed: Date;
}

export const missionTypesInitialState = [];
